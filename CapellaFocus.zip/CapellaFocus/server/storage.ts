import { type User, type InsertUser, type FocusSession, type InsertFocusSession, type UserSettings, type InsertUserSettings } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Focus Sessions
  createFocusSession(session: InsertFocusSession): Promise<FocusSession>;
  getFocusSessionsByUser(userId: string): Promise<FocusSession[]>;
  updateFocusSession(id: string, updates: Partial<FocusSession>): Promise<FocusSession | undefined>;
  
  // User Settings
  getUserSettings(userId: string): Promise<UserSettings | undefined>;
  createUserSettings(userId: string, settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: string, updates: Partial<InsertUserSettings>): Promise<UserSettings | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private focusSessions: Map<string, FocusSession>;
  private userSettings: Map<string, UserSettings>;

  constructor() {
    this.users = new Map();
    this.focusSessions = new Map();
    this.userSettings = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createFocusSession(session: InsertFocusSession): Promise<FocusSession> {
    const id = randomUUID();
    const focusSession: FocusSession = {
      ...session,
      id,
      completed: false,
      startedAt: new Date(),
      completedAt: null,
    };
    this.focusSessions.set(id, focusSession);
    return focusSession;
  }

  async getFocusSessionsByUser(userId: string): Promise<FocusSession[]> {
    return Array.from(this.focusSessions.values()).filter(
      (session) => session.userId === userId,
    );
  }

  async updateFocusSession(id: string, updates: Partial<FocusSession>): Promise<FocusSession | undefined> {
    const session = this.focusSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.focusSessions.set(id, updatedSession);
    return updatedSession;
  }

  async getUserSettings(userId: string): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(
      (settings) => settings.userId === userId,
    );
  }

  async createUserSettings(userId: string, settings: InsertUserSettings): Promise<UserSettings> {
    const id = randomUUID();
    const userSettings: UserSettings = {
      ...settings,
      id,
      userId,
    };
    this.userSettings.set(id, userSettings);
    return userSettings;
  }

  async updateUserSettings(userId: string, updates: Partial<InsertUserSettings>): Promise<UserSettings | undefined> {
    const settings = Array.from(this.userSettings.values()).find(
      (s) => s.userId === userId,
    );
    if (!settings) return undefined;
    
    const updatedSettings = { ...settings, ...updates };
    this.userSettings.set(settings.id, updatedSettings);
    return updatedSettings;
  }
}

export const storage = new MemStorage();
