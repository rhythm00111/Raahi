import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFocusSessionSchema, insertUserSettingsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock user ID for demo purposes (in real app this would come from authentication)
  const DEMO_USER_ID = "demo-user-123";

  // Get user settings
  app.get("/api/settings", async (req, res) => {
    try {
      let settings = await storage.getUserSettings(DEMO_USER_ID);
      
      if (!settings) {
        // Create default settings for new user
        settings = await storage.createUserSettings(DEMO_USER_ID, {
          workDuration: 25,
          shortBreakDuration: 5,
          longBreakDuration: 15,
          customSessions: true,
          distractionBlocker: false,
          ambientSounds: true,
          aiNudges: true,
          notifications: true,
          soundAlerts: true,
          autoStartBreaks: false,
          autoStartSessions: false,
        });
      }
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get settings" });
    }
  });

  // Update user settings
  app.patch("/api/settings", async (req, res) => {
    try {
      const updates = insertUserSettingsSchema.partial().parse(req.body);
      const settings = await storage.updateUserSettings(DEMO_USER_ID, updates);
      
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  // Create focus session
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertFocusSessionSchema.parse({
        ...req.body,
        userId: DEMO_USER_ID,
      });
      
      const session = await storage.createFocusSession(sessionData);
      res.json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid session data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create session" });
    }
  });

  // Complete focus session
  app.patch("/api/sessions/:id/complete", async (req, res) => {
    try {
      const { id } = req.params;
      const session = await storage.updateFocusSession(id, {
        completed: true,
        completedAt: new Date(),
      });
      
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete session" });
    }
  });

  // Get user focus sessions
  app.get("/api/sessions", async (req, res) => {
    try {
      const sessions = await storage.getFocusSessionsByUser(DEMO_USER_ID);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get sessions" });
    }
  });

  // Export focus data
  app.get("/api/export", async (req, res) => {
    try {
      const sessions = await storage.getFocusSessionsByUser(DEMO_USER_ID);
      const settings = await storage.getUserSettings(DEMO_USER_ID);
      
      const exportData = {
        sessions,
        settings,
        exportedAt: new Date().toISOString(),
      };
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="focus-data-export.json"');
      res.json(exportData);
    } catch (error) {
      res.status(500).json({ message: "Failed to export data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
