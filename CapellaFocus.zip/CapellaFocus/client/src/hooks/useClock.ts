import { useState, useEffect } from 'react';

export interface ClockTime {
  hours: number;
  minutes: number;
  seconds: number;
  digitalTime: string;
  digitalDate: string;
}

export function useClock(): ClockTime {
  const [time, setTime] = useState<ClockTime>(() => {
    const now = new Date();
    return {
      hours: now.getHours(),
      minutes: now.getMinutes(),
      seconds: now.getSeconds(),
      digitalTime: '',
      digitalDate: '',
    };
  });

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const seconds = now.getSeconds();

      const digitalTime = now.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
      });

      const day = now.getDate();
      const suffix = ['th', 'st', 'nd', 'rd'][day % 10 > 3 ? 0 : (day % 100 - day % 10 !== 10) * day % 10];
      const digitalDate = now.toLocaleDateString('en-US', {
        weekday: 'short',
        day: 'numeric',
        month: 'long',
      }).replace(day.toString(), `${day}${suffix}`);

      setTime({
        hours,
        minutes,
        seconds,
        digitalTime,
        digitalDate,
      });
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  return time;
}
