import { useState, useEffect, useCallback } from 'react';

export interface TimerState {
  timeRemaining: number;
  isRunning: boolean;
  sessionType: 'work' | 'short_break' | 'long_break';
  totalTime: number;
  progress: number;
}

export function useTimer(initialDuration: number = 25) {
  const [timerState, setTimerState] = useState<TimerState>({
    timeRemaining: initialDuration * 60,
    isRunning: false,
    sessionType: 'work',
    totalTime: initialDuration * 60,
    progress: 0,
  });

  const [sessionId, setSessionId] = useState<string | null>(null);

  const formatTime = useCallback((seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  const startTimer = useCallback(async () => {
    if (!timerState.isRunning) {
      // Create a new focus session
      try {
        const response = await fetch('/api/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionType: timerState.sessionType,
            duration: Math.floor(timerState.totalTime / 60),
          }),
        });
        const session = await response.json();
        setSessionId(session.id);
      } catch (error) {
        console.error('Failed to create session:', error);
      }

      setTimerState(prev => ({ ...prev, isRunning: true }));
    }
  }, [timerState.isRunning, timerState.sessionType, timerState.totalTime]);

  const pauseTimer = useCallback(() => {
    setTimerState(prev => ({ ...prev, isRunning: false }));
  }, []);

  const resetTimer = useCallback(() => {
    setTimerState(prev => ({
      ...prev,
      isRunning: false,
      timeRemaining: prev.totalTime,
      progress: 0,
    }));
    setSessionId(null);
  }, []);

  const skipSession = useCallback(() => {
    resetTimer();
  }, [resetTimer]);

  const updateDuration = useCallback((minutes: number) => {
    const seconds = minutes * 60;
    setTimerState(prev => ({
      ...prev,
      timeRemaining: seconds,
      totalTime: seconds,
      progress: 0,
    }));
  }, []);

  // Timer countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (timerState.isRunning && timerState.timeRemaining > 0) {
      interval = setInterval(() => {
        setTimerState(prev => {
          const newTimeRemaining = prev.timeRemaining - 1;
          const newProgress = 1 - (newTimeRemaining / prev.totalTime);

          if (newTimeRemaining <= 0) {
            // Timer completed
            if (sessionId) {
              fetch(`/api/sessions/${sessionId}/complete`, { method: 'PATCH' })
                .catch(console.error);
            }
            return {
              ...prev,
              timeRemaining: 0,
              isRunning: false,
              progress: 1,
            };
          }

          return {
            ...prev,
            timeRemaining: newTimeRemaining,
            progress: newProgress,
          };
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerState.isRunning, timerState.timeRemaining, sessionId]);

  return {
    ...timerState,
    formattedTime: formatTime(timerState.timeRemaining),
    startTimer,
    pauseTimer,
    resetTimer,
    skipSession,
    updateDuration,
  };
}
