import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import FocusMode from "@/pages/focus-mode";
import PomodoroDistraction from "@/components/PomodoroDistraction";
import NotFound from "@/pages/not-found";

function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-sm border-b border-white/20 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-teal-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">C</span>
          </div>
          <span className="font-bold text-slate-800">Capella Pro</span>
        </div>
        
        <div className="flex items-center gap-4">
          <Link href="/">
            <a className={`px-4 py-2 rounded-full transition-all duration-300 ${
              location === '/' 
                ? 'bg-teal-500 text-white shadow-lg' 
                : 'text-slate-600 hover:text-teal-600 hover:bg-teal-50'
            }`}>
              Focus Mode
            </a>
          </Link>
          <Link href="/pomodoro">
            <a className={`px-4 py-2 rounded-full transition-all duration-300 ${
              location === '/pomodoro' 
                ? 'bg-teal-500 text-white shadow-lg' 
                : 'text-slate-600 hover:text-teal-600 hover:bg-teal-50'
            }`}>
              Pomodoro Timer
            </a>
          </Link>
        </div>
      </div>
    </nav>
  );
}

function Router() {
  return (
    <div>
      <Navigation />
      <div className="pt-20">
        <Switch>
          <Route path="/" component={FocusMode} />
          <Route path="/pomodoro" component={PomodoroDistraction} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
