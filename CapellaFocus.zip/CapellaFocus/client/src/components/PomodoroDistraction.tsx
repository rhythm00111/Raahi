import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Shield, 
  Bell, 
  Eye, 
  CheckCircle,
  Target,
  Flame,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

interface PomodoroDistractionProps {
  className?: string;
}

type TimerMode = 'pomodoro' | 'shortBreak' | 'longBreak';

interface TimerState {
  timeRemaining: number;
  isRunning: boolean;
  mode: TimerMode;
}

interface FocusStats {
  completedSessions: number;
  currentStreak: number;
  totalFocusTime: number; // in minutes
}

interface DistractionSettings {
  blockSocialMedia: boolean;
  muteNotifications: boolean;
  focusMode: boolean;
}

const TIMER_DURATIONS = {
  pomodoro: 25 * 60, // 25 minutes in seconds
  shortBreak: 5 * 60, // 5 minutes in seconds
  longBreak: 15 * 60, // 15 minutes in seconds
};

export default function PomodoroDistraction({ className = '' }: PomodoroDistractionProps) {
  const [timer, setTimer] = useState<TimerState>({
    timeRemaining: TIMER_DURATIONS.pomodoro,
    isRunning: false,
    mode: 'pomodoro',
  });

  const [focusStats, setFocusStats] = useState<FocusStats>({
    completedSessions: 12,
    currentStreak: 5,
    totalFocusTime: 340, // 5h 40m
  });

  const [distractionSettings, setDistractionSettings] = useState<DistractionSettings>({
    blockSocialMedia: true,
    muteNotifications: true,
    focusMode: false,
  });

  const [autoStartNext, setAutoStartNext] = useState(false);

  // Timer logic
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (timer.isRunning && timer.timeRemaining > 0) {
      interval = setInterval(() => {
        setTimer(prev => ({
          ...prev,
          timeRemaining: prev.timeRemaining - 1,
        }));
      }, 1000);
    } else if (timer.timeRemaining === 0) {
      // Timer completed
      setTimer(prev => ({ ...prev, isRunning: false }));
      
      if (timer.mode === 'pomodoro') {
        setFocusStats(prev => ({
          ...prev,
          completedSessions: prev.completedSessions + 1,
          currentStreak: prev.currentStreak + 1,
          totalFocusTime: prev.totalFocusTime + 25,
        }));
      }

      // Auto-start next session logic
      if (autoStartNext) {
        setTimeout(() => {
          const nextMode = getNextMode(timer.mode);
          switchMode(nextMode);
          startTimer();
        }, 1000);
      }
    }

    return () => clearInterval(interval);
  }, [timer.isRunning, timer.timeRemaining, timer.mode, autoStartNext]);

  const getNextMode = (currentMode: TimerMode): TimerMode => {
    if (currentMode === 'pomodoro') {
      return focusStats.completedSessions % 4 === 0 ? 'longBreak' : 'shortBreak';
    }
    return 'pomodoro';
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = (): number => {
    const totalTime = TIMER_DURATIONS[timer.mode];
    return ((totalTime - timer.timeRemaining) / totalTime) * 100;
  };

  const startTimer = useCallback(() => {
    setTimer(prev => ({ ...prev, isRunning: true }));
  }, []);

  const pauseTimer = useCallback(() => {
    setTimer(prev => ({ ...prev, isRunning: false }));
  }, []);

  const resetTimer = useCallback(() => {
    setTimer(prev => ({
      ...prev,
      isRunning: false,
      timeRemaining: TIMER_DURATIONS[prev.mode],
    }));
  }, []);

  const switchMode = useCallback((mode: TimerMode) => {
    setTimer({
      timeRemaining: TIMER_DURATIONS[mode],
      isRunning: false,
      mode,
    });
  }, []);

  const getModeConfig = (mode: TimerMode) => {
    const configs = {
      pomodoro: { label: 'Pomodoro', color: 'bg-teal-500', textColor: 'text-teal-600' },
      shortBreak: { label: 'Short Break', color: 'bg-blue-500', textColor: 'text-blue-600' },
      longBreak: { label: 'Long Break', color: 'bg-purple-500', textColor: 'text-purple-600' },
    };
    return configs[mode];
  };

  const progress = getProgress();
  const circumference = 2 * Math.PI * 140;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const modeConfig = getModeConfig(timer.mode);

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 ${className}`}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Focus Timer</h1>
          <p className="text-slate-600">Stay focused, block distractions, achieve more</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Timer Section */}
          <div className="lg:col-span-2">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50">
              {/* Mode Selector */}
              <div className="flex justify-center gap-2 mb-8">
                {(['pomodoro', 'shortBreak', 'longBreak'] as TimerMode[]).map((mode) => {
                  const config = getModeConfig(mode);
                  const isActive = timer.mode === mode;
                  
                  return (
                    <Button
                      key={mode}
                      variant={isActive ? "default" : "outline"}
                      onClick={() => switchMode(mode)}
                      className={`px-6 py-2 rounded-full transition-all duration-300 ${
                        isActive 
                          ? `${config.color} text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1` 
                          : 'hover:bg-slate-100 hover:shadow-md'
                      }`}
                      data-testid={`mode-${mode}`}
                    >
                      {config.label}
                    </Button>
                  );
                })}
              </div>

              {/* Circular Timer */}
              <div className="flex justify-center mb-8">
                <div className="relative">
                  {/* Glow effect when running */}
                  {timer.isRunning && (
                    <motion.div
                      className="absolute inset-0 rounded-full"
                      style={{
                        background: `radial-gradient(circle, rgba(13, 148, 136, 0.2) 0%, transparent 70%)`,
                        filter: 'blur(20px)',
                      }}
                      animate={{
                        scale: [1, 1.1, 1],
                        opacity: [0.5, 0.8, 0.5],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                    />
                  )}
                  
                  <svg className="w-80 h-80 transform -rotate-90">
                    {/* Background circle */}
                    <circle
                      cx="160"
                      cy="160"
                      r="140"
                      fill="none"
                      stroke="#e2e8f0"
                      strokeWidth="8"
                    />
                    {/* Progress circle */}
                    <motion.circle
                      cx="160"
                      cy="160"
                      r="140"
                      fill="none"
                      stroke="url(#gradient)"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      transition={{ duration: 1, ease: "easeInOut" }}
                      style={{ filter: 'drop-shadow(0 0 10px rgba(13, 148, 136, 0.5))' }}
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#14b8a6" />
                        <stop offset="100%" stopColor="#0d9488" />
                      </linearGradient>
                    </defs>
                  </svg>
                  
                  {/* Timer display */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.div
                      className="text-6xl font-bold text-slate-800 mb-2"
                      animate={timer.isRunning ? { scale: [1, 1.02, 1] } : {}}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      {formatTime(timer.timeRemaining)}
                    </motion.div>
                    <div className={`text-lg font-medium ${modeConfig.textColor}`}>
                      {modeConfig.label}
                    </div>
                    <div className="text-sm text-slate-500 mt-1">
                      {Math.round(progress)}% complete
                    </div>
                  </div>
                </div>
              </div>

              {/* Timer Controls */}
              <div className="flex justify-center gap-4 mb-8">
                <Button
                  onClick={timer.isRunning ? pauseTimer : startTimer}
                  className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white px-8 py-4 rounded-2xl font-semibold shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
                  data-testid="play-pause-button"
                >
                  {timer.isRunning ? (
                    <>
                      <Pause className="w-5 h-5 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Start
                    </>
                  )}
                </Button>
                
                <Button
                  onClick={resetTimer}
                  variant="outline"
                  className="px-6 py-4 rounded-2xl font-medium border-2 hover:bg-slate-100 transition-all duration-300 hover:shadow-md hover:-translate-y-1"
                  data-testid="reset-button"
                >
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Reset
                </Button>
              </div>

              {/* Auto-start toggle */}
              <div className="flex items-center justify-center gap-3 p-4 bg-slate-50 rounded-2xl">
                <Switch 
                  checked={autoStartNext} 
                  onCheckedChange={setAutoStartNext}
                  data-testid="auto-start-toggle"
                />
                <span className="text-sm font-medium text-slate-700">
                  Auto-start next session
                </span>
              </div>
            </div>

            {/* Focus Stats Panel */}
            <div className="mt-6 bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-xl border border-white/50">
              <h3 className="text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-teal-600" />
                Focus Stats
              </h3>
              
              <div className="grid grid-cols-3 gap-4">
                <motion.div 
                  className="text-center p-4 bg-gradient-to-br from-teal-50 to-teal-100 rounded-2xl"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <CheckCircle className="w-6 h-6 text-teal-600" />
                  </div>
                  <div className="text-2xl font-bold text-teal-700">{focusStats.completedSessions}</div>
                  <div className="text-sm text-teal-600 font-medium">Sessions</div>
                </motion.div>
                
                <motion.div 
                  className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <Flame className="w-6 h-6 text-orange-600" />
                  </div>
                  <div className="text-2xl font-bold text-orange-700">{focusStats.currentStreak}</div>
                  <div className="text-sm text-orange-600 font-medium">Day Streak</div>
                </motion.div>
                
                <motion.div 
                  className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <Clock className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="text-2xl font-bold text-blue-700">
                    {Math.floor(focusStats.totalFocusTime / 60)}h {focusStats.totalFocusTime % 60}m
                  </div>
                  <div className="text-sm text-blue-600 font-medium">Total Time</div>
                </motion.div>
              </div>
            </div>
          </div>

          {/* Distraction Blocker Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-xl border border-white/50 h-fit">
              <h3 className="text-xl font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <Shield className="w-5 h-5 text-teal-600" />
                Distraction Blocker
              </h3>

              <div className="space-y-6">
                {/* Block Social Media */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-slate-700">Block Social Media</span>
                    <Switch 
                      checked={distractionSettings.blockSocialMedia}
                      onCheckedChange={(checked) => 
                        setDistractionSettings(prev => ({ ...prev, blockSocialMedia: checked }))
                      }
                      data-testid="block-social-toggle"
                    />
                  </div>
                  
                  <AnimatePresence>
                    {distractionSettings.blockSocialMedia && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-2 pl-4"
                      >
                        {['Facebook', 'Twitter', 'Instagram', 'TikTok', 'YouTube'].map((app) => (
                          <div key={app} className="flex items-center gap-2">
                            <input 
                              type="checkbox" 
                              defaultChecked 
                              className="rounded text-teal-600"
                              data-testid={`block-${app.toLowerCase()}`}
                            />
                            <span className="text-sm text-slate-600">{app}</span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Mute Notifications */}
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-slate-600" />
                    <span className="font-medium text-slate-700">Mute Notifications</span>
                  </div>
                  <Switch 
                    checked={distractionSettings.muteNotifications}
                    onCheckedChange={(checked) => 
                      setDistractionSettings(prev => ({ ...prev, muteNotifications: checked }))
                    }
                    data-testid="mute-notifications-toggle"
                  />
                </div>

                {/* Focus Mode */}
                <div className="flex items-center justify-between p-4 bg-teal-50 rounded-2xl">
                  <div className="flex items-center gap-3">
                    <Eye className="w-5 h-5 text-teal-600" />
                    <span className="font-medium text-slate-700">Focus Mode</span>
                  </div>
                  <Switch 
                    checked={distractionSettings.focusMode}
                    onCheckedChange={(checked) => 
                      setDistractionSettings(prev => ({ ...prev, focusMode: checked }))
                    }
                    data-testid="focus-mode-toggle"
                  />
                </div>

                {/* Status Indicators */}
                <div className="pt-4 border-t border-slate-200">
                  <h4 className="text-sm font-semibold text-slate-700 mb-3">Active Features</h4>
                  <div className="flex flex-wrap gap-2">
                    {distractionSettings.blockSocialMedia && (
                      <Badge className="bg-red-100 text-red-700 hover:bg-red-200">
                        🚫 Social Media Blocked
                      </Badge>
                    )}
                    {distractionSettings.muteNotifications && (
                      <Badge className="bg-orange-100 text-orange-700 hover:bg-orange-200">
                        🔕 Notifications Muted
                      </Badge>
                    )}
                    {distractionSettings.focusMode && (
                      <Badge className="bg-teal-100 text-teal-700 hover:bg-teal-200">
                        👁️ Focus Mode Active
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-6 bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-xl border border-white/50">
              <h3 className="text-lg font-semibold text-slate-800 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start hover:bg-teal-50 hover:border-teal-300 transition-all duration-300"
                  onClick={() => {
                    setDistractionSettings({
                      blockSocialMedia: true,
                      muteNotifications: true,
                      focusMode: true,
                    });
                  }}
                  data-testid="enable-all-button"
                >
                  Enable All Blockers
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start hover:bg-slate-50 transition-all duration-300"
                  onClick={() => {
                    setDistractionSettings({
                      blockSocialMedia: false,
                      muteNotifications: false,
                      focusMode: false,
                    });
                  }}
                  data-testid="disable-all-button"
                >
                  Disable All Blockers
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}