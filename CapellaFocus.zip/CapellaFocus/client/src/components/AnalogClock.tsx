import { useClock } from '@/hooks/useClock';
import { motion } from 'framer-motion';

export default function AnalogClock() {
  const { hours, minutes, seconds, digitalTime, digitalDate } = useClock();

  // Calculate angles for clock hands
  const hourAngle = (hours % 12) * 30 + minutes * 0.5;
  const minuteAngle = minutes * 6;
  const secondAngle = seconds * 6;

  // Format proper digital time (e.g., 12:00)
  const formatDigitalTime = () => {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  // Dynamic greeting based on time
  const getGreeting = () => {
    const now = new Date();
    const hour = now.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  // Calendar functions
  const getCurrentMonth = () => {
    const now = new Date();
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return monthNames[now.getMonth()];
  };

  const getDaysInMonth = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysCount = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days = [];
    for (let i = 0; i < startingDay; i++) {
      days.push(null);
    }
    for (let i = 1; i <= daysCount; i++) {
      days.push(i);
    }
    return days;
  };

  const currentDay = new Date().getDate();

  return (
    <div className="glass-card p-8 rounded-2xl h-96 flex" data-testid="analog-clock">
      {/* Left Side - Clock */}
      <div className="flex-1 flex flex-col justify-center">
        {/* Enhanced Clock with Glowing Ring */}
        <div className="relative mb-6">
          <motion.div
            className="w-32 h-32 mx-auto"
            animate={{ 
              filter: 'drop-shadow(0 0 30px rgba(13, 148, 136, 0.8))'
            }}
            transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse' }}
          >
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 128 128">
              {/* Hour dot markers */}
              {[...Array(12)].map((_, i) => {
                const angle = i * 30;
                const x = 64 + 50 * Math.cos((angle - 90) * Math.PI / 180);
                const y = 64 + 50 * Math.sin((angle - 90) * Math.PI / 180);
                return (
                  <circle
                    key={`hour-dot-${i}`}
                    cx={x}
                    cy={y}
                    r="2"
                    fill="rgba(13, 148, 136, 0.6)"
                  />
                );
              })}
              
              {/* Glowing background ring */}
              <circle
                cx="64"
                cy="64"
                r="55"
                fill="none"
                stroke="rgba(13, 148, 136, 0.1)"
                strokeWidth="2"
              />
              <motion.circle
                cx="64"
                cy="64"
                r="55"
                fill="none"
                stroke="url(#clockGradient)"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={345}
                strokeDashoffset={345 * 0.25}
                style={{ filter: 'drop-shadow(0 0 8px rgba(13, 148, 136, 0.6))' }}
              />
              
              {/* Clock Hands */}
              <line
                x1="64"
                y1="64"
                x2={64 + 25 * Math.cos((hourAngle - 90) * Math.PI / 180)}
                y2={64 + 25 * Math.sin((hourAngle - 90) * Math.PI / 180)}
                stroke="#333"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <line
                x1="64"
                y1="64"
                x2={64 + 35 * Math.cos((minuteAngle - 90) * Math.PI / 180)}
                y2={64 + 35 * Math.sin((minuteAngle - 90) * Math.PI / 180)}
                stroke="#333"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <motion.line
                x1="64"
                y1="64"
                x2={64 + 40 * Math.cos((secondAngle - 90) * Math.PI / 180)}
                y2={64 + 40 * Math.sin((secondAngle - 90) * Math.PI / 180)}
                stroke="hsl(168 76% 42%)"
                strokeWidth="1"
                strokeLinecap="round"
                transition={{ type: "spring", stiffness: 400, damping: 20 }}
              />
              
              {/* Center dot */}
              <circle cx="64" cy="64" r="3" fill="#333" />
              
              <defs>
                <linearGradient id="clockGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="hsl(168 76% 42%)" />
                  <stop offset="100%" stopColor="hsl(168 76% 52%)" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
        </div>
        
        {/* Digital Time with Elegant Typography */}
        <div className="text-center">
          <div className="text-4xl font-thin text-slate-800 mb-2" data-testid="digital-time">
            {formatDigitalTime()}
          </div>
          <div className="text-lg text-teal-600 font-light">{getGreeting()}</div>
          <div className="text-sm text-slate-500 mt-1" data-testid="digital-date">
            {digitalDate}
          </div>
        </div>
      </div>

      {/* Right Side - Premium Mini Calendar */}
      <div className="flex-1 flex flex-col justify-center pl-8">
        <div className="bg-slate-50/50 backdrop-blur-sm rounded-2xl p-4 border border-slate-200/50">
          <div className="text-center mb-3">
            <div className="text-lg font-light text-slate-700">
              {getCurrentMonth()} {new Date().getFullYear()}
            </div>
          </div>
          <div className="grid grid-cols-7 gap-1 text-xs">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, index) => (
              <div key={`day-${index}`} className="text-center text-slate-400 font-medium py-1">
                {day}
              </div>
            ))}
            {getDaysInMonth().map((day, index) => (
              <div
                key={index}
                className={`text-center py-1 rounded-md transition-all duration-200 ${
                  day === currentDay 
                    ? 'bg-teal-500 text-white font-semibold shadow-lg' 
                    : day 
                      ? 'text-slate-600 hover:bg-teal-50 hover:text-teal-700 cursor-pointer' 
                      : ''
                }`}
              >
                {day || ''}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
