import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX, Play, Pause, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface FocusSoundsProps {
  className?: string;
}

interface Sound {
  id: string;
  name: string;
  emoji: string;
  description: string;
  color: string;
}

export default function FocusSounds({ className = '' }: FocusSoundsProps) {
  const [selectedSound, setSelectedSound] = useState<string>('rain');
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([65]);
  const [isMuted, setIsMuted] = useState(false);

  const sounds: Sound[] = [
    {
      id: 'silence',
      name: 'Silence',
      emoji: '🔇',
      description: 'Pure silence for maximum focus',
      color: 'from-gray-500 to-gray-600',
    },
    {
      id: 'rain',
      name: 'Rain',
      emoji: '🌧️',
      description: 'Gentle rainfall sounds',
      color: 'from-blue-500 to-blue-600',
    },
    {
      id: 'ocean',
      name: 'Ocean',
      emoji: '🌊',
      description: 'Calming ocean waves',
      color: 'from-cyan-500 to-blue-500',
    },
    {
      id: 'lofi',
      name: 'Lo-Fi',
      emoji: '🎵',
      description: 'Chill lo-fi hip hop beats',
      color: 'from-purple-500 to-indigo-500',
    },
    {
      id: 'forest',
      name: 'Forest',
      emoji: '🌲',
      description: 'Birds chirping in a forest',
      color: 'from-green-500 to-emerald-500',
    },
    {
      id: 'cafe',
      name: 'Café',
      emoji: '☕',
      description: 'Coffee shop ambiance',
      color: 'from-orange-500 to-red-500',
    },
  ];

  const currentSound = sounds.find(s => s.id === selectedSound) || sounds[0];

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const resetToDefault = () => {
    setSelectedSound('rain');
    setVolume([65]);
    setIsMuted(false);
    setIsPlaying(false);
  };

  return (
    <div className={`glass-card p-6 rounded-2xl ${className}`} data-testid="focus-sounds">
      <div className="flex items-center gap-3 mb-6">
        <div className={`w-10 h-10 bg-gradient-to-br ${currentSound.color} rounded-xl flex items-center justify-center`}>
          <Volume2 className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-semibold text-foreground">Focus Sounds</h3>
          <p className="text-sm text-muted-foreground">Ambient audio for deep focus</p>
        </div>
      </div>

      {/* Sound Selection */}
      <div className="mb-6">
        <label className="text-sm font-medium text-muted-foreground mb-3 block">
          Choose Your Ambiance
        </label>
        <Select value={selectedSound} onValueChange={setSelectedSound}>
          <SelectTrigger className="w-full rounded-xl bg-card/50 border-border/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {sounds.map((sound) => (
              <SelectItem key={sound.id} value={sound.id}>
                <div className="flex items-center gap-3">
                  <span className="text-lg">{sound.emoji}</span>
                  <div>
                    <div className="font-medium">{sound.name}</div>
                    <div className="text-xs text-muted-foreground">{sound.description}</div>
                  </div>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Current Sound Display */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedSound}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className={`p-4 rounded-xl bg-gradient-to-r ${currentSound.color} bg-opacity-10 border border-current/20 mb-6`}
        >
          <div className="flex items-center gap-4">
            <div className="text-3xl">{currentSound.emoji}</div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground">{currentSound.name}</h4>
              <p className="text-sm text-muted-foreground">{currentSound.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <div className={`w-2 h-2 rounded-full ${isPlaying ? 'bg-green-500' : 'bg-gray-400'} animate-pulse`} />
                <span className="text-xs text-muted-foreground">
                  {isPlaying ? 'Playing' : 'Paused'}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Controls */}
      <div className="space-y-4">
        {/* Play Controls */}
        <div className="flex justify-center gap-3">
          <Button
            onClick={togglePlayPause}
            className={`w-12 h-12 rounded-full p-0 ${isPlaying 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-primary hover:bg-primary/90'
            } text-white shadow-lg transition-all duration-300 hover:scale-105`}
            data-testid="toggle-play-sound"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
          </Button>
          
          <Button
            onClick={toggleMute}
            variant="secondary"
            className="w-12 h-12 rounded-full p-0 transition-all duration-300 hover:scale-105"
            data-testid="toggle-mute-sound"
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </Button>
          
          <Button
            onClick={resetToDefault}
            variant="secondary"
            className="w-12 h-12 rounded-full p-0 transition-all duration-300 hover:scale-105"
            data-testid="reset-sound-settings"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        {/* Volume Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-muted-foreground">Volume</label>
            <span className="text-sm text-muted-foreground">{isMuted ? 0 : volume[0]}%</span>
          </div>
          <Slider
            value={isMuted ? [0] : volume}
            onValueChange={setVolume}
            max={100}
            step={5}
            className="w-full"
            disabled={isMuted}
            data-testid="volume-slider"
          />
        </div>
      </div>

      {/* Sound Presets */}
      <div className="mt-6 p-4 bg-card/30 rounded-xl border border-border/50">
        <h4 className="text-sm font-semibold text-foreground mb-3">Quick Presets</h4>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => { setSelectedSound('rain'); setVolume([45]); }}
            className="text-xs rounded-lg"
          >
            🌧️ Light Rain
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => { setSelectedSound('lofi'); setVolume([35]); }}
            className="text-xs rounded-lg"
          >
            🎵 Study Beats
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => { setSelectedSound('forest'); setVolume([50]); }}
            className="text-xs rounded-lg"
          >
            🌲 Nature Sounds
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => { setSelectedSound('silence'); setVolume([0]); }}
            className="text-xs rounded-lg"
          >
            🔇 Pure Silence
          </Button>
        </div>
      </div>
    </div>
  );
}