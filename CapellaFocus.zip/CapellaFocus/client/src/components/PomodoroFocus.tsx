import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  SkipForward, 
  Clock, 
  Shield, 
  Music, 
  Palette, 
  BarChart3, 
  Brain,
  Target,
  Flame,
  CheckCircle,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

interface PomodoroFocusProps {
  className?: string;
}

export default function PomodoroFocus({ className = '' }: PomodoroFocusProps) {
  const [timeRemaining, setTimeRemaining] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showStatsOverview, setShowStatsOverview] = useState(false);
  const [showFocusSounds, setShowFocusSounds] = useState(false);

  const [features, setFeatures] = useState([
    { id: 'customSessions', label: 'Custom Sessions', icon: Clock, enabled: true, type: 'toggle' },
    { id: 'distractionBlocker', label: 'Distraction Blocker', icon: Shield, enabled: false, type: 'toggle' },
    { id: 'ambientSounds', label: 'Focus Sounds', icon: Music, enabled: true, type: 'button' },
    { id: 'themeSelector', label: 'Theme Selector', icon: Palette, enabled: false, type: 'button' },
    { id: 'focusStats', label: 'Focus Stats', icon: BarChart3, enabled: false, type: 'button' },
    { id: 'aiNudges', label: 'AI Nudges', icon: Brain, enabled: true, type: 'toggle' },
  ]);

  // Timer logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeRemaining]);

  // Clock update
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const startTimer = useCallback(() => setIsRunning(true), []);
  const pauseTimer = useCallback(() => setIsRunning(false), []);
  const resetTimer = useCallback(() => {
    setIsRunning(false);
    setTimeRemaining(25 * 60);
  }, []);
  const skipSession = useCallback(() => {
    setIsRunning(false);
    setTimeRemaining(0);
  }, []);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDigitalTime = (): string => {
    return currentTime.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  const getGreeting = (): string => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 18) return 'Good Afternoon';
    return 'Good Evening';
  };

  const getProgress = (): number => {
    return ((25 * 60 - timeRemaining) / (25 * 60)) * 100;
  };

  const toggleFeature = (id: string) => {
    setFeatures(prev => prev.map(feature => 
      feature.id === id ? { ...feature, enabled: !feature.enabled } : feature
    ));
  };

  const handleButtonClick = (id: string) => {
    if (id === 'focusStats') {
      setShowStatsOverview(!showStatsOverview);
    } else if (id === 'ambientSounds') {
      setShowFocusSounds(!showFocusSounds);
    }
  };

  const progress = getProgress();
  const circumference = 2 * Math.PI * 160;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  // Calendar data
  const getCurrentMonth = () => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return monthNames[currentTime.getMonth()];
  };

  const getDaysInMonth = () => {
    const year = currentTime.getFullYear();
    const month = currentTime.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysCount = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days = [];
    for (let i = 0; i < startingDay; i++) {
      days.push(null);
    }
    for (let i = 1; i <= daysCount; i++) {
      days.push(i);
    }
    return days;
  };

  const weekData = [
    { day: 'Mon', minutes: 85 },
    { day: 'Tue', minutes: 125 },
    { day: 'Wed', minutes: 45 },
    { day: 'Thu', minutes: 95 },
    { day: 'Fri', minutes: 160 },
    { day: 'Sat', minutes: 75 },
    { day: 'Sun', minutes: 40 },
  ];

  const totalWeekMinutes = weekData.reduce((sum, d) => sum + d.minutes, 0);

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 ${className}`}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Main Content Grid - Equal Height Boxes */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Clock Box */}
          <motion.div
            className="h-96 bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50 flex"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Left Side - Clock */}
            <div className="flex-1 flex flex-col justify-center">
              <div className="relative mb-6">
                <motion.div
                  className="w-32 h-32 mx-auto"
                  animate={isRunning ? { 
                    filter: 'drop-shadow(0 0 30px rgba(13, 148, 136, 0.8))'
                  } : {}}
                  transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse' }}
                >
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 128 128">
                    <circle
                      cx="64"
                      cy="64"
                      r="60"
                      fill="none"
                      stroke="rgba(13, 148, 136, 0.1)"
                      strokeWidth="2"
                    />
                    <motion.circle
                      cx="64"
                      cy="64"
                      r="60"
                      fill="none"
                      stroke="url(#clockGradient)"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeDasharray={377}
                      strokeDashoffset={377 * 0.25}
                      style={{ filter: 'drop-shadow(0 0 8px rgba(13, 148, 136, 0.6))' }}
                    />
                    <defs>
                      <linearGradient id="clockGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="hsl(168 76% 42%)" />
                        <stop offset="100%" stopColor="hsl(168 76% 52%)" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-xs text-teal-600 font-medium">NOW</div>
                    </div>
                  </div>
                </motion.div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-thin text-slate-800 mb-2">{formatDigitalTime()}</div>
                <div className="text-lg text-teal-600 font-light">{getGreeting()}</div>
                <div className="text-sm text-slate-500 mt-1">
                  {currentTime.toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </div>
              </div>
            </div>

            {/* Right Side - Mini Calendar */}
            <div className="flex-1 flex flex-col justify-center pl-8">
              <div className="bg-slate-50/50 rounded-2xl p-4">
                <div className="text-center mb-3">
                  <div className="text-lg font-medium text-slate-700">
                    {getCurrentMonth()} {currentTime.getFullYear()}
                  </div>
                </div>
                <div className="grid grid-cols-7 gap-1 text-xs">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day) => (
                    <div key={day} className="text-center text-slate-400 font-medium py-1">
                      {day}
                    </div>
                  ))}
                  {getDaysInMonth().map((day, index) => (
                    <div
                      key={index}
                      className={`text-center py-1 rounded-md ${
                        day === currentTime.getDate() 
                          ? 'bg-teal-500 text-white font-semibold' 
                          : day 
                            ? 'text-slate-600 hover:bg-slate-100 cursor-pointer' 
                            : ''
                      }`}
                    >
                      {day || ''}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Pomodoro Box */}
          <motion.div
            className="h-96 bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50 flex flex-col items-center justify-center"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h2 className="text-2xl font-light text-slate-800 mb-8">Pomodoro Session</h2>
            
            {/* Larger Circular Timer */}
            <div className="relative mb-8">
              <motion.div
                className="w-48 h-48"
                animate={isRunning ? { 
                  filter: 'drop-shadow(0 0 40px rgba(13, 148, 136, 0.8))'
                } : {}}
                transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse' }}
              >
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 192 192">
                  <circle
                    cx="96"
                    cy="96"
                    r="80"
                    fill="none"
                    stroke="rgba(13, 148, 136, 0.1)"
                    strokeWidth="8"
                  />
                  <motion.circle
                    cx="96"
                    cy="96"
                    r="80"
                    fill="none"
                    stroke="url(#timerGradient)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={circumference * 0.83}
                    strokeDashoffset={strokeDashoffset * 0.83}
                    transition={{ duration: 1, ease: "easeInOut" }}
                    style={{ filter: 'drop-shadow(0 0 15px rgba(13, 148, 136, 0.6))' }}
                  />
                  <defs>
                    <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="hsl(168 76% 42%)" />
                      <stop offset="100%" stopColor="hsl(168 76% 52%)" />
                    </linearGradient>
                  </defs>
                </svg>
                
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-5xl font-thin text-slate-800 mb-2">{formatTime(timeRemaining)}</div>
                  <div className="text-sm text-slate-500">{Math.round(progress)}% complete</div>
                </div>
              </motion.div>
            </div>

            {/* Timer Controls */}
            <div className="flex gap-3">
              <Button
                onClick={isRunning ? pauseTimer : startTimer}
                className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white px-6 py-3 rounded-xl font-medium shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {isRunning ? 'Pause' : 'Start'}
              </Button>
              
              <Button
                onClick={resetTimer}
                variant="outline"
                className="px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:-translate-y-1"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
              
              <Button
                onClick={skipSession}
                variant="outline"
                className="px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:-translate-y-1"
              >
                <SkipForward className="w-4 h-4 mr-2" />
                Skip
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Focus Features Panel */}
        <motion.div
          className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <h3 className="text-2xl font-light text-slate-800 mb-8">Focus Features</h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              
              return (
                <motion.div
                  key={feature.id}
                  className="group p-6 rounded-2xl border border-slate-200/50 bg-slate-50/30 transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ 
                    boxShadow: '0 0 30px rgba(13, 148, 136, 0.3)',
                    scale: 1.02 
                  }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-medium text-slate-700">{feature.label}</span>
                    </div>
                    
                    {feature.type === 'toggle' ? (
                      <Switch 
                        checked={feature.enabled} 
                        onCheckedChange={() => toggleFeature(feature.id)}
                      />
                    ) : (
                      <Button
                        onClick={() => handleButtonClick(feature.id)}
                        variant="outline"
                        size="sm"
                        className="px-4 py-2 rounded-lg text-xs font-medium transition-all duration-300 hover:bg-teal-50 hover:border-teal-300 hover:text-teal-700"
                      >
                        {feature.id === 'ambientSounds' ? 'Open' : 'View'}
                      </Button>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Enhanced Weekly Focus Stats */}
        <motion.div
          className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          whileHover={{ y: -4, boxShadow: '0 20px 60px rgba(0, 0, 0, 0.1)' }}
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-light text-slate-800">Weekly Focus Analytics</h3>
              <p className="text-slate-500 mt-1">Your productivity insights</p>
            </div>
            <div className="flex items-center gap-1 text-teal-600">
              <TrendingUp className="w-5 h-5" />
              <span className="font-medium">+15% this week</span>
            </div>
          </div>

          {/* 3 Levels of Stats */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {/* Level 1: Sessions Completed */}
            <motion.div 
              className="text-center p-6 bg-gradient-to-br from-teal-50 to-teal-100 rounded-2xl border border-teal-200/50"
              whileHover={{ scale: 1.05 }}
            >
              <CheckCircle className="w-8 h-8 text-teal-600 mx-auto mb-3" />
              <div className="text-3xl font-thin text-teal-700 mb-1">47</div>
              <div className="text-sm font-medium text-teal-600">Sessions Completed</div>
              <div className="text-xs text-teal-500 mt-1">+8 from last week</div>
            </motion.div>

            {/* Level 2: Total Minutes */}
            <motion.div 
              className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl border border-blue-200/50"
              whileHover={{ scale: 1.05 }}
            >
              <Clock className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <div className="text-3xl font-thin text-blue-700 mb-1">{totalWeekMinutes}</div>
              <div className="text-sm font-medium text-blue-600">Total Minutes</div>
              <div className="text-xs text-blue-500 mt-1">{Math.round(totalWeekMinutes / 60)}h {totalWeekMinutes % 60}m focused</div>
            </motion.div>

            {/* Level 3: Productivity % */}
            <motion.div 
              className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl border border-purple-200/50"
              whileHover={{ scale: 1.05 }}
            >
              <Target className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <div className="text-3xl font-thin text-purple-700 mb-1">94%</div>
              <div className="text-sm font-medium text-purple-600">Productivity Score</div>
              <div className="text-xs text-purple-500 mt-1">Above weekly goal</div>
            </motion.div>
          </div>

          {/* Weekly Chart */}
          <div className="flex items-end justify-between gap-3 h-32">
            {weekData.map((day, index) => {
              const maxMinutes = Math.max(...weekData.map(d => d.minutes));
              const height = (day.minutes / maxMinutes) * 100;
              
              return (
                <div key={day.day} className="flex-1 flex flex-col items-center group">
                  <motion.div
                    className="w-full bg-gradient-to-t from-teal-500 to-teal-400 rounded-t-lg transition-all duration-300 group-hover:from-teal-600 group-hover:to-teal-500 group-hover:shadow-lg"
                    initial={{ height: 0 }}
                    animate={{ height: `${height}%` }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                  />
                  <div className="mt-2 text-center">
                    <div className="text-sm font-medium text-slate-700">{day.day}</div>
                    <div className="text-xs text-slate-500">{day.minutes}m</div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Expandable Sections */}
        <AnimatePresence>
          {showStatsOverview && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50"
            >
              <h3 className="text-2xl font-light text-slate-800 mb-6">Detailed Statistics</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center p-4 bg-slate-50 rounded-xl">
                  <Flame className="w-6 h-6 text-orange-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-slate-800">12</div>
                  <div className="text-sm text-slate-600">Day Streak</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-xl">
                  <Target className="w-6 h-6 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-slate-800">89%</div>
                  <div className="text-sm text-slate-600">Success Rate</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-xl">
                  <Clock className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-slate-800">23m</div>
                  <div className="text-sm text-slate-600">Avg Session</div>
                </div>
                <div className="text-center p-4 bg-slate-50 rounded-xl">
                  <BarChart3 className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-slate-800">340h</div>
                  <div className="text-sm text-slate-600">Total Time</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}