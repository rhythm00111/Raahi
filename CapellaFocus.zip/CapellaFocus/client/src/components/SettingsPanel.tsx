import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { UserSettings } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onWorkDurationChange: (minutes: number) => void;
}

export default function SettingsPanel({ isOpen, onClose, onWorkDurationChange }: SettingsPanelProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ['/api/settings'],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (updates: Partial<UserSettings>) => {
      const response = await apiRequest('PATCH', '/api/settings', updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      toast({
        title: "Settings updated",
        description: "Your preferences have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const [localSettings, setLocalSettings] = useState<Partial<UserSettings>>({});

  useEffect(() => {
    if (settings) {
      setLocalSettings(settings);
    }
  }, [settings]);

  const handleSliderChange = (key: keyof UserSettings, value: number[]) => {
    const newValue = value[0];
    setLocalSettings(prev => ({ ...prev, [key]: newValue }));
    updateSettingsMutation.mutate({ [key]: newValue });
    
    if (key === 'workDuration') {
      onWorkDurationChange(newValue);
    }
  };

  const handleToggleChange = (key: keyof UserSettings, value: boolean) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
    updateSettingsMutation.mutate({ [key]: value });
  };

  return (
    <>
      {/* Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            data-testid="settings-overlay"
          />
        )}
      </AnimatePresence>

      {/* Settings Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed top-0 right-0 w-96 h-full bg-card shadow-2xl z-50 border-l border-border"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            data-testid="settings-panel"
          >
            <div className="p-6 border-b border-border">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-foreground">Settings</h2>
                <Button
                  onClick={onClose}
                  variant="ghost"
                  size="sm"
                  className="p-2 hover:bg-accent rounded-lg"
                  data-testid="button-close-settings"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>
            
            <div className="p-6 space-y-6 overflow-y-auto h-full pb-24">
              {isLoading ? (
                <div className="text-center py-8">
                  <div className="text-muted-foreground">Loading settings...</div>
                </div>
              ) : (
                <>
                  {/* Timer Durations */}
                  <div>
                    <h3 className="font-medium text-foreground mb-4">Timer Durations</h3>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label className="text-sm text-muted-foreground">Work Session</label>
                          <span className="text-sm font-medium text-foreground" data-testid="text-work-duration">
                            {localSettings.workDuration || 25}m
                          </span>
                        </div>
                        <Slider
                          value={[localSettings.workDuration || 25]}
                          onValueChange={(value) => handleSliderChange('workDuration', value)}
                          min={5}
                          max={60}
                          step={5}
                          className="w-full"
                          data-testid="slider-work-duration"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label className="text-sm text-muted-foreground">Short Break</label>
                          <span className="text-sm font-medium text-foreground" data-testid="text-short-break">
                            {localSettings.shortBreakDuration || 5}m
                          </span>
                        </div>
                        <Slider
                          value={[localSettings.shortBreakDuration || 5]}
                          onValueChange={(value) => handleSliderChange('shortBreakDuration', value)}
                          min={2}
                          max={15}
                          step={1}
                          className="w-full"
                          data-testid="slider-short-break"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <label className="text-sm text-muted-foreground">Long Break</label>
                          <span className="text-sm font-medium text-foreground" data-testid="text-long-break">
                            {localSettings.longBreakDuration || 15}m
                          </span>
                        </div>
                        <Slider
                          value={[localSettings.longBreakDuration || 15]}
                          onValueChange={(value) => handleSliderChange('longBreakDuration', value)}
                          min={10}
                          max={45}
                          step={5}
                          className="w-full"
                          data-testid="slider-long-break"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Notifications */}
                  <div>
                    <h3 className="font-medium text-foreground mb-4">Notifications</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-muted-foreground">Desktop Notifications</label>
                        <Switch
                          checked={localSettings.notifications || false}
                          onCheckedChange={(value) => handleToggleChange('notifications', value)}
                          data-testid="toggle-notifications"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-muted-foreground">Sound Alerts</label>
                        <Switch
                          checked={localSettings.soundAlerts || false}
                          onCheckedChange={(value) => handleToggleChange('soundAlerts', value)}
                          data-testid="toggle-sound-alerts"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Advanced Settings */}
                  <div>
                    <h3 className="font-medium text-foreground mb-4">Advanced</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-muted-foreground">Auto-start Breaks</label>
                        <Switch
                          checked={localSettings.autoStartBreaks || false}
                          onCheckedChange={(value) => handleToggleChange('autoStartBreaks', value)}
                          data-testid="toggle-auto-start-breaks"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <label className="text-sm text-muted-foreground">Auto-start Sessions</label>
                        <Switch
                          checked={localSettings.autoStartSessions || false}
                          onCheckedChange={(value) => handleToggleChange('autoStartSessions', value)}
                          data-testid="toggle-auto-start-sessions"
                        />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
