import { Download, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface TopBarProps {
  onOpenSettings: () => void;
}

export default function TopBar({ onOpenSettings }: TopBarProps) {
  const { toast } = useToast();

  const handleExport = async () => {
    try {
      const response = await fetch('/api/export');
      
      if (!response.ok) {
        throw new Error('Export failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'focus-data-export.json';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export completed",
        description: "Your focus data has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export focus data. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="flex justify-between items-center mb-8" data-testid="top-bar">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Focus Mode</h1>
        <p className="text-muted-foreground mt-1">Boost your productivity with focused work sessions</p>
      </div>
      <div className="flex gap-3">
        <Button
          onClick={handleExport}
          variant="secondary"
          className="px-4 py-2 rounded-xl font-medium shadow-sm transition-all duration-300 hover:-translate-y-1"
          data-testid="button-export"
        >
          <Download className="w-5 h-5 mr-2" />
          Export
        </Button>
        <Button
          onClick={onOpenSettings}
          variant="secondary"
          className="px-4 py-2 rounded-xl font-medium shadow-sm transition-all duration-300 hover:-translate-y-1"
          data-testid="button-settings"
        >
          <Settings className="w-5 h-5 mr-2" />
          Settings
        </Button>
      </div>
    </header>
  );
}
