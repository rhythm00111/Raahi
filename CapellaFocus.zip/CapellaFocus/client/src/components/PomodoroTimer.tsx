import { motion, AnimatePresence } from 'framer-motion';
import { useTimer } from '@/hooks/useTimer';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';
import { useState, useEffect } from 'react';

interface PomodoroTimerProps {
  workDuration: number;
}

export default function PomodoroTimer({ workDuration }: PomodoroTimerProps) {
  const timer = useTimer(workDuration);
  const [showRipple, setShowRipple] = useState(false);
  const [aiNudge, setAiNudge] = useState('');

  const circumference = 2 * Math.PI * 160; // Larger radius
  const strokeDashoffset = circumference * (1 - timer.progress);

  const getStatusText = () => {
    if (timer.isRunning) return 'Deep focus mode active';
    if (timer.timeRemaining === timer.totalTime) return 'Ready to achieve greatness';
    if (timer.timeRemaining === 0) return 'Outstanding work! 🎉';
    return 'Focus session paused';
  };

  const nudges = [
    "Stay sharp ✨",
    "You're crushing it! 🚀",
    "Deep focus unlocked 🔥",
    "Flow state activated 💫",
    "Greatness in progress ⭐",
    "You're in the zone! 🎯",
    "Momentum building 💪",
    "Excellence mode on 🌟"
  ];

  useEffect(() => {
    if (timer.isRunning) {
      setShowRipple(true);
      const rippleTimer = setTimeout(() => setShowRipple(false), 1000);
      
      // Show AI nudges periodically
      const nudgeInterval = setInterval(() => {
        if (Math.random() > 0.7) { // 30% chance every interval
          const randomNudge = nudges[Math.floor(Math.random() * nudges.length)];
          setAiNudge(randomNudge);
          setTimeout(() => setAiNudge(''), 3000);
        }
      }, 10000); // Every 10 seconds

      return () => {
        clearTimeout(rippleTimer);
        clearInterval(nudgeInterval);
      };
    }
  }, [timer.isRunning]);

  return (
    <div className="glass-card p-8 rounded-2xl h-96 flex flex-col items-center justify-center" data-testid="pomodoro-timer">
      <h2 className="text-2xl font-light text-slate-800 mb-8" data-testid="session-title">
        Pomodoro Session
      </h2>
      
      {/* AI Nudge */}
      <AnimatePresence>
        {aiNudge && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="mb-4 px-4 py-2 bg-primary/10 border border-primary/20 rounded-full text-primary font-medium text-sm"
          >
            {aiNudge}
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Larger Circular Timer with Contained Animation */}
      <div className="relative mb-8 overflow-hidden">
        {/* Ripple Animation - Contained within timer box */}
        <AnimatePresence>
          {showRipple && (
            <motion.div
              className="absolute inset-0 rounded-full border-4 border-teal-500/50"
              initial={{ scale: 0.8, opacity: 1 }}
              animate={{ scale: 1.2, opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              style={{ zIndex: 0 }}
            />
          )}
        </AnimatePresence>

        <motion.div
          className="w-48 h-48 relative z-10"
          animate={timer.isRunning ? { 
            filter: 'drop-shadow(0 0 40px rgba(13, 148, 136, 0.8))'
          } : {}}
          transition={{ duration: 2, repeat: timer.isRunning ? Infinity : 0, repeatType: 'reverse' }}
        >
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 192 192">
            {/* Background circle */}
            <circle
              cx="96"
              cy="96"
              r="80"
              fill="none"
              stroke="rgba(13, 148, 136, 0.1)"
              strokeWidth="8"
            />
            {/* Progress circle */}
            <motion.circle
              cx="96"
              cy="96"
              r="80"
              fill="none"
              stroke="url(#timerGradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              transition={{ duration: 1, ease: "easeInOut" }}
              style={{ filter: 'drop-shadow(0 0 15px rgba(13, 148, 136, 0.6))' }}
            />
            {/* Gradient definition */}
            <defs>
              <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="hsl(168 76% 42%)" />
                <stop offset="100%" stopColor="hsl(168 76% 52%)" />
              </linearGradient>
            </defs>
          </svg>
        </motion.div>
        
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center z-20">
          {/* Thinner, More Elegant Number Text */}
          <div className="text-5xl font-thin text-slate-800 mb-2" data-testid="timer-display">
            {timer.formattedTime}
          </div>
          <div className="text-sm text-slate-500">
            {Math.round(timer.progress * 100)}% complete
          </div>
        </div>
      </div>

      {/* Timer Controls */}
      <div className="flex gap-3">
        <Button
          onClick={timer.startTimer}
          disabled={timer.isRunning}
          className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white px-6 py-3 rounded-xl font-medium shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
          data-testid="button-start"
        >
          <Play className="w-4 h-4 mr-2" />
          {timer.isRunning ? 'Running' : 'Start'}
        </Button>
        
        <Button
          onClick={timer.pauseTimer}
          disabled={!timer.isRunning}
          variant="outline"
          className="px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:-translate-y-1"
          data-testid="button-pause"
        >
          <Pause className="w-4 h-4 mr-2" />
          Pause
        </Button>
        
        <Button
          onClick={timer.resetTimer}
          variant="outline"
          className="px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:-translate-y-1"
          data-testid="button-reset"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
        
        <Button
          onClick={timer.skipSession}
          variant="outline"
          className="px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:-translate-y-1"
          data-testid="button-skip"
        >
          <SkipForward className="w-4 h-4 mr-2" />
          Skip
        </Button>
      </div>
    </div>
  );
}
