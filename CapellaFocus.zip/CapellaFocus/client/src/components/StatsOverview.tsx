import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Clock, Target, Calendar, Zap, Award, TrendingUp } from 'lucide-react';
import type { FocusSession } from '@shared/schema';

interface StatsOverviewProps {
  className?: string;
}

export default function StatsOverview({ className = '' }: StatsOverviewProps) {
  const { data: sessions = [] } = useQuery<FocusSession[]>({
    queryKey: ['/api/sessions'],
  });

  // Calculate stats (mock data for demo)
  const stats = {
    todayMinutes: 125,
    longestStreak: 12,
    avgDaily: 89,
    totalSessions: sessions.length + 47,
    completedSessions: sessions.filter(s => s.completed).length + 42,
    currentStreak: 8,
  };

  const statCards = [
    {
      id: 'today',
      title: 'Today\'s Focus',
      value: `${stats.todayMinutes}m`,
      subtitle: `${Math.round(stats.todayMinutes / 60 * 10) / 10}h total`,
      icon: Clock,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-500/10',
      textColor: 'text-blue-600',
    },
    {
      id: 'streak',
      title: 'Current Streak',
      value: `${stats.currentStreak}`,
      subtitle: 'days in a row',
      icon: Zap,
      color: 'from-orange-500 to-red-500',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-orange-600',
    },
    {
      id: 'longest',
      title: 'Longest Streak',
      value: `${stats.longestStreak}`,
      subtitle: 'days (personal best!)',
      icon: Award,
      color: 'from-yellow-500 to-orange-500',
      bgColor: 'bg-yellow-500/10',
      textColor: 'text-yellow-600',
    },
    {
      id: 'average',
      title: 'Daily Average',
      value: `${stats.avgDaily}m`,
      subtitle: 'last 30 days',
      icon: TrendingUp,
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-500/10',
      textColor: 'text-green-600',
    },
    {
      id: 'sessions',
      title: 'Total Sessions',
      value: `${stats.totalSessions}`,
      subtitle: `${stats.completedSessions} completed`,
      icon: Target,
      color: 'from-purple-500 to-indigo-500',
      bgColor: 'bg-purple-500/10',
      textColor: 'text-purple-600',
    },
    {
      id: 'monthly',
      title: 'This Month',
      value: '18.5h',
      subtitle: '74% of goal',
      icon: Calendar,
      color: 'from-primary to-primary/80',
      bgColor: 'bg-primary/10',
      textColor: 'text-primary',
    },
  ];

  return (
    <div className={`glass-card p-6 rounded-2xl ${className}`} data-testid="stats-overview">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/80 rounded-xl flex items-center justify-center">
          <Award className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-xl font-semibold text-foreground">Focus Stats</h3>
          <p className="text-sm text-muted-foreground">Your productivity insights</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((stat, index) => {
          const IconComponent = stat.icon;
          
          return (
            <motion.div
              key={stat.id}
              className="relative p-4 rounded-xl border border-border/50 bg-card/30 backdrop-blur-sm overflow-hidden group hover:shadow-lg transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -2 }}
              data-testid={`stat-${stat.id}`}
            >
              {/* Background gradient overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-3">
                  <div className={`w-8 h-8 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                    <IconComponent className={`w-4 h-4 ${stat.textColor}`} />
                  </div>
                  <div className="text-right">
                    <motion.div
                      className="text-2xl font-bold text-foreground"
                      initial={{ scale: 1 }}
                      whileHover={{ scale: 1.1 }}
                    >
                      {stat.value}
                    </motion.div>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-foreground text-sm">{stat.title}</h4>
                  <p className="text-xs text-muted-foreground mt-1">{stat.subtitle}</p>
                </div>

                {/* Progress indicator for certain stats */}
                {stat.id === 'monthly' && (
                  <div className="mt-3">
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                      <motion.div
                        className="bg-primary h-1.5 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: '74%' }}
                        transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Achievement badges */}
      <div className="mt-6 p-4 bg-gradient-to-r from-primary/5 to-indigo-500/5 rounded-xl border border-primary/20">
        <h4 className="text-sm font-semibold text-foreground mb-3">Recent Achievements</h4>
        <div className="flex gap-2 flex-wrap">
          <div className="px-3 py-1 bg-yellow-500/10 text-yellow-600 text-xs rounded-full border border-yellow-500/20">
            🏆 Week Warrior (7 days)
          </div>
          <div className="px-3 py-1 bg-blue-500/10 text-blue-600 text-xs rounded-full border border-blue-500/20">
            ⚡ Early Bird (5 AM start)
          </div>
          <div className="px-3 py-1 bg-green-500/10 text-green-600 text-xs rounded-full border border-green-500/20">
            🎯 Goal Crusher (100% week)
          </div>
        </div>
      </div>
    </div>
  );
}