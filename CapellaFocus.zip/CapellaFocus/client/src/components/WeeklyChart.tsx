import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { BarChart3, TrendingUp, Target, CheckCircle, Clock } from 'lucide-react';
import type { FocusSession } from '@shared/schema';

interface WeeklyChartProps {
  className?: string;
}

export default function WeeklyChart({ className = '' }: WeeklyChartProps) {
  const { data: sessions = [] } = useQuery<FocusSession[]>({
    queryKey: ['/api/sessions'],
  });

  // Generate mock data for the week (in a real app this would come from actual sessions)
  const weekData = [
    { day: 'Mon', minutes: 85, date: 'Sep 2' },
    { day: 'Tue', minutes: 125, date: 'Sep 3' },
    { day: 'Wed', minutes: 45, date: 'Sep 4' },
    { day: 'Thu', minutes: 95, date: 'Sep 5' },
    { day: 'Fri', minutes: 160, date: 'Sep 6' },
    { day: 'Sat', minutes: 75, date: 'Sep 7' },
    { day: 'Sun', minutes: 40, date: 'Sep 8' },
  ];

  const maxMinutes = Math.max(...weekData.map(d => d.minutes));
  const totalWeekMinutes = weekData.reduce((sum, d) => sum + d.minutes, 0);
  const avgDailyMinutes = Math.round(totalWeekMinutes / 7);

  return (
    <motion.div 
      className={`bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50 ${className}`} 
      data-testid="weekly-chart"
      whileHover={{ y: -4, boxShadow: '0 20px 60px rgba(0, 0, 0, 0.1)' }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-2xl font-light text-slate-800">Weekly Focus Analytics</h3>
          <p className="text-slate-500 mt-1">Your productivity insights</p>
        </div>
        <div className="flex items-center gap-1 text-teal-600">
          <TrendingUp className="w-5 h-5" />
          <span className="font-medium">+15% this week</span>
        </div>
      </div>

      {/* 3 Levels of Detail Stats */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {/* Level 1: Sessions Completed */}
        <motion.div 
          className="text-center p-6 bg-gradient-to-br from-teal-50 to-teal-100 rounded-2xl border border-teal-200/50"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        >
          <CheckCircle className="w-8 h-8 text-teal-600 mx-auto mb-3" />
          <div className="text-3xl font-thin text-teal-700 mb-1">47</div>
          <div className="text-sm font-medium text-teal-600">Sessions Completed</div>
          <div className="text-xs text-teal-500 mt-1">+8 from last week</div>
        </motion.div>

        {/* Level 2: Total Minutes */}
        <motion.div 
          className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl border border-blue-200/50"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        >
          <Clock className="w-8 h-8 text-blue-600 mx-auto mb-3" />
          <div className="text-3xl font-thin text-blue-700 mb-1">{totalWeekMinutes}</div>
          <div className="text-sm font-medium text-blue-600">Total Minutes</div>
          <div className="text-xs text-blue-500 mt-1">{Math.round(totalWeekMinutes / 60)}h {totalWeekMinutes % 60}m focused</div>
        </motion.div>

        {/* Level 3: Productivity % */}
        <motion.div 
          className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl border border-purple-200/50"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        >
          <Target className="w-8 h-8 text-purple-600 mx-auto mb-3" />
          <div className="text-3xl font-thin text-purple-700 mb-1">94%</div>
          <div className="text-sm font-medium text-purple-600">Productivity Score</div>
          <div className="text-xs text-purple-500 mt-1">Above weekly goal</div>
        </motion.div>
      </div>

      {/* Enhanced Bar Chart */}
      <div className="flex items-end justify-between gap-3 h-32">
        {weekData.map((day, index) => {
          const height = (day.minutes / maxMinutes) * 100;
          const isToday = index === 1; // Tuesday (today)
          
          return (
            <div key={day.day} className="flex-1 flex flex-col items-center group">
              <motion.div
                className={`w-full rounded-t-lg transition-all duration-300 group-hover:scale-105 ${
                  isToday 
                    ? 'bg-gradient-to-t from-teal-600 to-teal-500 shadow-lg' 
                    : 'bg-gradient-to-t from-teal-500 to-teal-400'
                } group-hover:from-teal-600 group-hover:to-teal-500 group-hover:shadow-lg`}
                initial={{ height: 0 }}
                animate={{ height: `${height}%` }}
                transition={{ duration: 0.8, delay: index * 0.1, ease: "easeOut" }}
                data-testid={`chart-bar-${day.day.toLowerCase()}`}
              />
              
              <div className="mt-2 text-center">
                <div className={`text-sm font-medium ${isToday ? 'text-teal-700' : 'text-slate-700'}`}>
                  {day.day}
                </div>
                <div className="text-xs text-slate-500">{day.minutes}m</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Premium Weekly Goal Progress */}
      <div className="mt-8 p-6 bg-gradient-to-r from-teal-50 to-blue-50 rounded-2xl border border-teal-200/50">
        <div className="flex items-center justify-between mb-3">
          <span className="text-lg font-medium text-slate-800">Weekly Goal Progress</span>
          <span className="text-sm text-slate-600 font-medium">
            {totalWeekMinutes}/840 min
          </span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-3 shadow-inner">
          <motion.div
            className="bg-gradient-to-r from-teal-500 to-blue-500 h-3 rounded-full shadow-lg"
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((totalWeekMinutes / 840) * 100, 100)}%` }}
            transition={{ duration: 1.5, delay: 0.5 }}
          />
        </div>
        <div className="text-sm text-slate-600 mt-2 flex items-center justify-between">
          <span>{Math.round((totalWeekMinutes / 840) * 100)}% of your 14-hour weekly goal</span>
          <span className="text-teal-600 font-medium">🎯 On track!</span>
        </div>
      </div>
    </motion.div>
  );
}