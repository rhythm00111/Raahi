import { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Shield, Music, Palette, BarChart3, Brain } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';

interface FeaturePanelProps {
  onViewStats: () => void;
  onOpenThemeSelector: () => void;
  onToggleFocusSounds: () => void;
}

interface FeatureToggle {
  id: string;
  label: string;
  icon: any;
  enabled: boolean;
  type: 'toggle' | 'button';
}

export default function FeaturePanel({ onViewStats, onOpenThemeSelector, onToggleFocusSounds }: FeaturePanelProps) {
  const [features, setFeatures] = useState<FeatureToggle[]>([
    { id: 'customSessions', label: 'Custom Sessions', icon: Clock, enabled: true, type: 'toggle' },
    { id: 'distractionBlocker', label: 'Distraction Blocker', icon: Shield, enabled: false, type: 'toggle' },
    { id: 'ambientSounds', label: 'Focus Sounds', icon: Music, enabled: true, type: 'button' },
    { id: 'themeSelector', label: 'Theme Selector', icon: Palette, enabled: false, type: 'button' },
    { id: 'focusStats', label: 'Focus Stats', icon: BarChart3, enabled: false, type: 'button' },
    { id: 'aiNudges', label: 'AI Nudges', icon: Brain, enabled: true, type: 'toggle' },
  ]);

  const toggleFeature = (id: string) => {
    setFeatures(prev => prev.map(feature => 
      feature.id === id ? { ...feature, enabled: !feature.enabled } : feature
    ));
  };

  const handleButtonClick = (id: string) => {
    if (id === 'focusStats') {
      onViewStats();
    } else if (id === 'themeSelector') {
      onOpenThemeSelector();
    } else if (id === 'ambientSounds') {
      onToggleFocusSounds();
    }
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/50" data-testid="feature-panel">
      <h3 className="text-2xl font-light text-slate-800 mb-8">Focus Features</h3>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => {
          const IconComponent = feature.icon;
          
          return (
            <motion.div
              key={feature.id}
              className="group p-6 rounded-2xl border border-slate-200/50 bg-slate-50/30 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 relative overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ 
                boxShadow: '0 0 30px rgba(13, 148, 136, 0.3)',
                scale: 1.02 
              }}
              data-testid={`feature-${feature.id}`}
            >
              {/* Glowing Teal Outline Behind Button Box Only */}
              <div className="absolute inset-0 bg-gradient-to-r from-teal-500/10 to-teal-600/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="relative z-10 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                    <IconComponent className="w-5 h-5 text-white" />
                  </div>
                  <span className="font-medium text-slate-700">{feature.label}</span>
                </div>
                
                {feature.type === 'toggle' ? (
                  <Switch 
                    checked={feature.enabled} 
                    onCheckedChange={() => toggleFeature(feature.id)}
                    data-testid={`toggle-${feature.id}`}
                  />
                ) : (
                  <Button
                    onClick={() => handleButtonClick(feature.id)}
                    variant="outline"
                    size="sm"
                    className="px-4 py-2 rounded-lg text-xs font-medium transition-all duration-300 hover:bg-teal-50 hover:border-teal-300 hover:text-teal-700 hover:shadow-md"
                    data-testid={`button-${feature.id}`}
                  >
                    {feature.id === 'themeSelector' ? 'Light' : 
                     feature.id === 'ambientSounds' ? 'Open' : 'View'}
                  </Button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
