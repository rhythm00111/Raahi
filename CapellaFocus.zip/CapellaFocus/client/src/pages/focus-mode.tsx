import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import AnalogClock from '@/components/AnalogClock';
import PomodoroTimer from '@/components/PomodoroTimer';
import WeeklyChart from '@/components/WeeklyChart';
import StatsOverview from '@/components/StatsOverview';
import FocusSounds from '@/components/FocusSounds';
import FeaturePanel from '@/components/FeaturePanel';
import SettingsPanel from '@/components/SettingsPanel';
import TopBar from '@/components/TopBar';
import type { UserSettings } from '@shared/schema';

export default function FocusMode() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showStatsOverview, setShowStatsOverview] = useState(false);
  const [showFocusSounds, setShowFocusSounds] = useState(false);

  const { data: settings } = useQuery<UserSettings>({
    queryKey: ['/api/settings'],
  });

  const handleViewStats = () => {
    setShowStatsOverview(!showStatsOverview);
  };

  const handleOpenThemeSelector = () => {
    // TODO: Implement theme selector modal
    console.log('Theme selector opened');
  };

  const handleToggleFocusSounds = () => {
    setShowFocusSounds(!showFocusSounds);
  };

  const handleWorkDurationChange = (minutes: number) => {
    // This will be handled by the PomodoroTimer component through props
  };

  return (
    <div className="min-h-screen p-6" data-testid="focus-mode-page">
      <TopBar onOpenSettings={() => setIsSettingsOpen(true)} />

      {/* Main Content Grid */}
      <div className="grid xl:grid-cols-2 gap-8 mb-8">
        {/* Left Section: Clock + Calendar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <AnalogClock />
        </motion.div>

        {/* Right Section: Pomodoro Timer */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <PomodoroTimer workDuration={settings?.workDuration || 25} />
        </motion.div>
      </div>

      {/* Weekly Productivity Chart */}
      <motion.div
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <WeeklyChart />
      </motion.div>

      {/* Feature Panel */}
      <motion.div
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <FeaturePanel 
          onViewStats={handleViewStats}
          onOpenThemeSelector={handleOpenThemeSelector}
          onToggleFocusSounds={handleToggleFocusSounds}
        />
      </motion.div>

      {/* Expandable Sections */}
      <div className="space-y-8">
        {/* Stats Overview */}
        {showStatsOverview && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4 }}
          >
            <StatsOverview />
          </motion.div>
        )}

        {/* Focus Sounds */}
        {showFocusSounds && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4 }}
          >
            <FocusSounds />
          </motion.div>
        )}
      </div>

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onWorkDurationChange={handleWorkDurationChange}
      />
    </div>
  );
}
