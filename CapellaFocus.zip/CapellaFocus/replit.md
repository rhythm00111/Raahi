# Overview

This is a full-stack Focus Mode web application built for productivity enhancement. The app provides a Pomodoro timer with customizable work sessions, an analog clock, feature toggles for productivity tools, and comprehensive user settings management. It's designed as a single-page application with a clean, modern interface using glass morphism design patterns.

The application serves as a productivity workspace where users can manage focus sessions, configure their preferred work/break durations, and access various productivity features like distraction blocking, ambient sounds, and AI-powered nudges.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript in a Vite-powered development environment
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management with built-in caching
- **UI Framework**: Radix UI primitives with shadcn/ui components providing accessible, customizable components
- **Styling**: Tailwind CSS with custom CSS variables for theming and glass morphism effects
- **Animations**: Framer Motion for smooth animations and transitions
- **Form Handling**: React Hook Form with Zod validation

## Backend Architecture  
- **Runtime**: Node.js with Express.js as the web server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints following conventional patterns
- **Development**: Hot reload with Vite integration in development mode
- **Static Assets**: Vite handles bundling and serves static files in production

## Data Layer
- **Database**: PostgreSQL configured for production use
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Centralized schema definitions in shared directory for type consistency
- **Storage**: In-memory storage implementation for development, with database interfaces ready for production
- **Migrations**: Drizzle Kit handles database schema migrations

## Authentication & Sessions
- **User Management**: Basic user system with username/password authentication (prepared but not fully implemented)
- **Session Storage**: PostgreSQL session store via connect-pg-simple
- **Demo Mode**: Uses hardcoded demo user for development and testing

## Component Architecture
- **Design System**: Shadcn/ui providing consistent component library
- **Layout**: Glass card-based layout with responsive grid system
- **Reusable Components**: Modular components for timer, clock, settings, and feature panels
- **Theming**: CSS custom properties enable dynamic theming

## Data Flow
- **Client-Server**: REST API with JSON payloads
- **Caching**: TanStack Query provides intelligent client-side caching
- **Real-time Updates**: Timer state managed locally with periodic server sync
- **Error Handling**: Centralized error handling with user-friendly toast notifications

## Key Features
- **Pomodoro Timer**: Customizable work/break durations with visual progress indication
- **Analog Clock**: Real-time clock with smooth hand animations
- **Settings Management**: Persistent user preferences for all productivity features
- **Feature Toggles**: Enable/disable productivity features like distraction blocking, ambient sounds, AI nudges
- **Data Export**: User data export functionality
- **Responsive Design**: Mobile-first approach with adaptive layouts

# External Dependencies

## Core Framework Dependencies
- **@vitejs/plugin-react**: React support for Vite build system
- **express**: Web server framework for API endpoints
- **wouter**: Lightweight routing library for single-page navigation

## Database & ORM
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **drizzle-orm**: TypeScript ORM for database operations  
- **drizzle-kit**: Database migration and schema management tools
- **connect-pg-simple**: PostgreSQL session store for Express

## State Management & API
- **@tanstack/react-query**: Server state management with caching and synchronization
- **zod**: Runtime type validation and schema definition
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation

## UI Components & Styling
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework for styling
- **class-variance-authority**: Utility for creating component variants
- **clsx**: Conditional className utility

## Animation & Interaction
- **framer-motion**: Animation library for smooth transitions and interactions
- **embla-carousel-react**: Carousel component for potential future features

## Form Handling
- **react-hook-form**: Performant form library with minimal re-renders
- **@hookform/resolvers**: Validation resolvers for React Hook Form

## Development Tools
- **typescript**: Static type checking for enhanced development experience
- **tsx**: TypeScript execution environment for development server
- **esbuild**: Fast JavaScript bundler for production builds

## Utility Libraries
- **date-fns**: Date manipulation and formatting utilities
- **nanoid**: URL-safe unique ID generator
- **cmdk**: Command palette component for potential future features